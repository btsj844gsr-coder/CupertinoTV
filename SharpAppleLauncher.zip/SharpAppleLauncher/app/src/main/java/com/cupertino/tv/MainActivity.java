package com.cupertino.tv;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    LinearLayout root, appsRow;
    int focusIndex = 0;
    List<View> tiles = new ArrayList<>();
    List<ApplicationInfo> launchable = new ArrayList<>();
    PackageManager pm;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    GradientDrawable bg(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b); pm=getPackageManager(); buildUi(); }
    void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(46),dp(28),dp(46),dp(22)); root.setBackgroundColor(Color.rgb(10,13,20));
        setContentView(root);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        TextView brand=text("Cupertino",22,Color.WHITE,true); top.addView(brand,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView time=text("TV   •   ANDROID TV",13,Color.rgb(174,184,202),false); top.addView(time); root.addView(top);
        TextView hello=text("Всё, что вы смотрите.",31,Color.WHITE,true); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(56)); hp.topMargin=dp(22); root.addView(hello,hp);
        TextView sub=text("Ваши приложения — в одном месте",16,Color.rgb(166,176,194),false); root.addView(sub);
        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(dp(28),dp(20),dp(28),dp(18)); hero.setFocusable(true); hero.setFocusableInTouchMode(true);
        hero.setBackground(bg(Color.rgb(28,37,56),22,Color.rgb(64,82,112),1));
        TextView kicker=text("ПРОДОЛЖИТЬ ПРОСМОТР",12,Color.rgb(194,210,238),true); hero.addView(kicker);
        TextView title=text("Выберите приложение",25,Color.WHITE,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(46)); tp.topMargin=dp(8); hero.addView(title,tp);
        TextView desc=text("Нажмите на карточку ниже, чтобы открыть сервис",14,Color.rgb(190,199,215),false); hero.addView(desc);
        LinearLayout.LayoutParams herop=new LinearLayout.LayoutParams(-1,dp(128)); herop.topMargin=dp(24); root.addView(hero,herop);
        TextView label=text("ПРИЛОЖЕНИЯ",13,Color.rgb(166,176,194),true); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(34)); lp.topMargin=dp(20); root.addView(label,lp);
        ScrollView sc=new ScrollView(this); sc.setHorizontalScrollBarEnabled(false); appsRow=new LinearLayout(this); appsRow.setOrientation(LinearLayout.HORIZONTAL); sc.addView(appsRow); root.addView(sc,new LinearLayout.LayoutParams(-1,dp(118)));
        loadApps();
        TextView foot=text("Используйте стрелки и OK на пульте   •   Настройки и сервисы зависят от системы телевизора",12,Color.rgb(112,124,145),false); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(36)); fp.topMargin=dp(10); root.addView(foot,fp);
        if (!tiles.isEmpty()) tiles.get(0).requestFocus();
    }
    void loadApps() {
        String[] preferred={"com.google.android.youtube.tv","com.google.android.youtube","com.netflix.ninja","com.disney.disneyplus","com.amazon.amazonvideo.livingroom","com.google.android.tvlauncher","com.android.chrome"};
        List<ApplicationInfo> all=pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for(String p:preferred) for(ApplicationInfo a:all) if(a.packageName.equals(p) && pm.getLaunchIntentForPackage(p)!=null && !launchable.contains(a)) launchable.add(a);
        for(ApplicationInfo a:all) {
            if(pm.getLaunchIntentForPackage(a.packageName)!=null && !a.packageName.equals(getPackageName()) && !launchable.contains(a)) launchable.add(a);
        }
        int count=0;
        for(ApplicationInfo a:launchable) {
            if(count++>=12) break;
            LinearLayout tile=new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER); tile.setFocusable(true); tile.setFocusableInTouchMode(true); tile.setPadding(dp(10),dp(8),dp(10),dp(8));
            tile.setBackground(bg(Color.rgb(24,29,40),16,Color.TRANSPARENT,0));
            TextView icon=text("",27,Color.WHITE,true); icon.setGravity(Gravity.CENTER); try { icon.setCompoundDrawables(null,null,null,null); icon.setText(pm.getApplicationLabel(a).toString().substring(0,1).toUpperCase()); } catch(Exception e) { icon.setText("•"); }
            TextView name=text(pm.getApplicationLabel(a).toString(),13,Color.WHITE,true); name.setGravity(Gravity.CENTER); name.setMaxLines(1);
            tile.addView(icon,new LinearLayout.LayoutParams(-1,dp(43))); tile.addView(name,new LinearLayout.LayoutParams(dp(116),dp(26)));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(132),dp(94)); p.rightMargin=dp(12); appsRow.addView(tile,p); tiles.add(tile);
            tile.setOnFocusChangeListener((v,has)->v.setBackground(bg(has?Color.rgb(48,62,86):Color.rgb(24,29,40),16,has?Color.WHITE:Color.TRANSPARENT,has?2:0)));
            tile.setOnClickListener(v->{ Intent i=pm.getLaunchIntentForPackage(a.packageName); if(i!=null) try {startActivity(i);} catch(Exception ignored){} });
        }
        if(tiles.isEmpty()) { TextView none=text("Не удалось найти приложения для запуска",15,Color.WHITE,false); appsRow.addView(none); }
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode==KeyEvent.KEYCODE_BACK) { return true; }
        return super.onKeyDown(keyCode,event);
    }
}
