# Cupertino TV — prototype launcher for Android TV

Minimal native Android TV launcher inspired by Apple's restrained dark UI. It uses only Android framework APIs and has no third-party runtime dependencies.

## Build in a cloud Linux environment

Requires JDK 17 and Android SDK platform 35/build-tools installed, plus Gradle 8.7 or newer.

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

This is an untested prototype. The launcher can list and open installed apps, but the available apps and Android TV's HOME selection behavior depend on the TV firmware. It does not speed up the underlying operating system or fix hardware/firmware hangs. No Gradle wrapper is included.
